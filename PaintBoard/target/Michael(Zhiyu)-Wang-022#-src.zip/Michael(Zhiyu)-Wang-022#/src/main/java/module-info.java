open module gameoflife {

	requires java.sql;
	requires java.desktop; 
	requires javafx.web;
	requires javafx.base;
	requires transitive javafx.graphics;
	requires transitive javafx.controls;
}